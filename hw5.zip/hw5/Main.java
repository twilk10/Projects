/*Tyler Wilkerson test sleep method threads*/
package hw5;
//import java.lang.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//THis brings in the class of TestSleep
		Runnable runnable = new TestSleep(); 
		/*This makes the thread */
		Thread t1 = new Thread(runnable);
		/*This makes the thread and keeps it active*/
        t1.start();
	}

}
