/*Tyler Wilkerson this code takes user input of 2 numbers and prints the times tables for them*/package hw5;

import java.util.Scanner;
public class Multiply{
public static void main(String[] args) throws InterruptedException{
	//This instantiates a table object from class table 
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter two numbers you want to see the times tables of");
	int x = sc.nextInt();
	int y = sc.nextInt();
Table table=new Table();
//This creates an object for both of the threads
thread_one first=new thread_one(table,x);
thread_two second=new thread_two(table,y);
//These two commands start the threads which also runs them but makes them active
first.start();
//join does something similar to synchronize 
first.join();

second.start();

second.join();

//System.out.println(Thread.activeCount());

}
}

