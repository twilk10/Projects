/*Tyler Wilkerson This compares a reversed string to a regular string to see if it is a palindrome*/
package hw5;
import java.util.*;
class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		//THis calls the reversestring method to see if the reverse string is equal to the regular string input by the user
		System.out.println("is "+s+" a palindrome? "+ reverseString(s).equals(s));
		//System.out.println(reverseString(s));
	}
	public static String reverseString(String str)
    {
        if (str.isEmpty())
            return str;
        //Calls Function Recursively
       // System.out.println(str.substring(1)+"\t"+str.charAt(0));
        return reverseString(str.substring(1)) + str.charAt(0);
    }

}
