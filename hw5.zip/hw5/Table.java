/*Tyler Wilkerson this creates the table from which the multiplication table is maid */
package hw5;

class Table{
	
 static void printable(int n){
	for(int i=1;i<=10;i++){
		//This prints out the number times whatever loop it is on
	System.out.print(i*n+" ");

	try{
		//This makes the thread sleep for half a second so that it waits to print out the next element
	Thread.sleep(500);
}
	catch(Exception e){
	System.out.println(e);
}
}
	System.out.print("\n");

}
}


