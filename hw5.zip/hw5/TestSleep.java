/*Tyler Wilkerson
 * This creates a thread that implements runnable */package hw5;
//This makes testSleep implement Runnable 
public class TestSleep implements Runnable  {
	public void run() {
		//This is the for loop for 10 of the numbers to run
		for(int i = 1;i<=10;i++) {
			System.out.println(i);
			try {
				//This puts the thread to sleep for 1000 miliseconds
				Thread.sleep(1000);
				//This gives the exception for if there is an interupted exception
			}catch(InterruptedException e) {
	            System.out.println("An Excetion occured: " + e);
	         }finally{}
		}
	}
}
