package hw5;
import java.util.*;
class TimesTables1{
public static void main(String[] args) throws InterruptedException{
	//This instantiates a table object from class table 
	
	Scanner sc = new Scanner(System.in);
	int x = sc.nextInt();
	int y = sc.nextInt();
Table table=new Table();
//This creates an object for both of the threads
thread_one first=new thread_one(table,x);
thread_two second=new thread_two(table,y);
//These two commands start the threads which also runs them but makes them active
first.start();
first.join();
second.start();
second.join();
//System.out.println(Thread.activeCount());

}
}
