package hw5;

public class multiplyTable {

}
