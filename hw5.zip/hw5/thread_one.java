/*Tyler Wilkerson this creates a thread*/package hw5;

class thread_one extends Thread{
Table t1;
int y;
thread_one(Table entry,int y ){
	//This equates the table that was instantiated in this class to what was put into the super
t1=entry;
this.y=y;
}
public void run(){
	//this takes the table and runs the mutiply table method for the value of y
t1.printable(y);
}
}