/*Tyler Wilkerson this creates a thread*/package hw5;

class thread_two extends Thread{
	//this initializes Table
Table t1;
int x;
thread_two(Table entry,int x){
	//this makes Table t1 whatever was put into the constructor of thread 2
t1=entry;
this.x=x;
}
public void run(){
	//this takes the table and runs the mutiply table method for the value of y
t1.printable(x);
}
}