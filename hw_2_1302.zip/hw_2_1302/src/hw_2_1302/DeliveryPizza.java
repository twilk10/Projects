package hw_2_1302;
//import java.util.*;
/*Original code by Tyler Wilkerson what this code does is add an address and the delivery fee to the price and kind
 * of pizza*/
public class DeliveryPizza extends Pizza{
		/*What this does is it adds the delivery fee to the price of the pizza*/
	public double finalCost;
		String x;
		double y;
		public String address;
	//Scanner sc = new Scanner (System.in);
		
		
	/*What this method does is it takes in the price of the Pizza the type of Pizza and the address 
	 * and then puts those attributes to variables to be used later*/
	public DeliveryPizza(String x, double y,String d) {
		super(x, y);
		this.x = x;
		this.y = y;
		this.address = d;
		// TODO Auto-generated constructor stub
		}
	/*This returns the total cost which means the cost plus the delivery fee and it also prints out just the type of Pizza 
	 * and the cost not including the delivery fee and the address this uses the varaibles from the constructer for 
	 * this class to put variables into a constructor from the variables put into the constructor of the child class*/
	public void totalCost(){
			/*Pizza P1 = new Pizza();
			P1.order();
			System.out.println(P1.orderCost());*/
			
		
		
		 /*This uses the variables put into the child class as variables put into the constructor
		  * of the parent class*/
		   Pizza P1 = new Pizza(x,y);
		   //P1.pizzaAndCost();
		   
		   
		   
		   
		   
		/*This if statement evaluates if the price of the pizza is more or less than $20 to see if the delivery 
		 * fee is $2 or $5*/
		if(y>20) {
			finalCost = 2 + P1.pizzaAndCost();
			String h = String.format("%.2f", finalCost);
		System.out.println(x+" pizza plus the delivery fee of $2.00 is $"+h+" and will be delivered to the address "+address);
		}else {
			finalCost = 5 + P1.pizzaAndCost();
			String h = String.format("%.2f", finalCost);
			System.out.println(x+" pizza plus the delivery fee of $5.00 is $"+h+" and will be delivered to the adress "+address);

		}
		
		
		   
	   }
}
