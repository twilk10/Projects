package hw_2_1302;
/*This is an original code by Tyler Wilkerson and what this part of the code does is make two objects and 
 * prints the type of Pizza the full cost and the address it should be delivered too*/
public class DemoPizzas {
	public static void main(String[] args) {
		/*This initializes an object P1 of a bologna 
		 * Pizza that cost 25 dollars and will be delivered to an address*/
		DeliveryPizza P1 = new DeliveryPizza("bologna", 25,"1234 Candy Cane Lane Helena, Montana 45265");
		P1.totalCost();
		/*This initializes an object called P2 which is an onion and sausage Pizza
		 * that costs 13 dollars and will be delivered to an address.*/
		DeliveryPizza P2 = new DeliveryPizza("sasusage and onion", 13,"4859 Dreary Road Missoula, Montana 45275");
		P2.totalCost();
	}
}
