package hw_2_1302;
import java.util.*;
/*Original code By Tyler Wilkerson this code goes through preselected values and gets them if they are in 
 * the position they shpuld be in and has a quit statement at 999*/
public class MorgansBonuses {
	public static void main(String[] args) {
		getBonus();
	}
	
	/*This method is used to first find How many weeks an Employee has worked and then use a switch statement 
	 * to find how many positive reviews they got then get the bonus from the pre-made bonus list */
	public static void getBonus() {
		
		int x = 0;
		/*The while loop with x<5 is used to keep the code running because 0 is less than 5*/
		while(x<5) {
		System.out.println("Enter the number of full weeks worked of the employee and then how many positive reviews the employee has gotten");
		Scanner sc = new Scanner (System.in);
		int c = sc.nextInt();
		
		
		/*This part of the code is here so that if someone enters 999 the code will immedietly end by making 
		 * x 300 which is more than 5*/
		if(c==999) {
			x=300;
			
		}else {
			int y = sc.nextInt();
	  /*This goes through the switch statement if weeks worked is 0*/
		if(c==0) {
			switch (y) {
			case 0:
				System.out.println("The bonus will be $"+5+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+9+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+16+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+24+".00");
				break;
			case 999:
				x=300;
				break;
			default:
				System.out.println("The bonus will be $"+30+".00");
				break;
			
			}
		
			
			
			/*This goes through the switch statement if weeks worked is 1*/
		}else if(c==1) {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+15+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+12+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+18+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+24+".00");
				break;
			default:
				System.out.println("The bonus will be $"+36+".00");
				break;
			
			}
			/*This goes through the switch statement if weeks worked is 2*/
		}else if(c==2) {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+20+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+26+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+32+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+41+".00");
				break;
			default:
				System.out.println("The bonus will be $"+53+".00");
				break;
			
			}
			
			
			
			/*This goes through the switch statement if weeks worked is 3*/
		}else if(c==3) {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+32+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+28+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+45+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+55+".00");
				break;
			default:
				System.out.println("The bonus will be $"+68+".00");
				break;
			
			}
			/*This goes through the switch statement if weeks worked is 4*/
		}else if(c==4) {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+46+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+54+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+65+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+57+".00");
				break;
			default:
				System.out.println("The bonus will be $"+90+".00");
				break;
			
			}
		
			
			
			
			/*This goes through the switch statement if weeks worked is 5*/
		}else if(c==5) {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+65+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+72+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+84+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+96+".00");
				break;
			default:
				System.out.println("The bonus will be $"+123+".00");
				break;
			
			}
			
			
			
			/*This goes through the switch statement if weeks worked is 6 or more*/
		}else {
			switch (y) {
			case 999:
				x=300;
				break;
			case 0:
				System.out.println("The bonus will be $"+85+".00");
				break;
			case 1:
				System.out.println("The bonus will be $"+100+".00");
				break;
			case 2:
				System.out.println("The bonus will be $"+120+".00");
				break;
			case 3:
				System.out.println("The bonus will be $"+139+".00");
				break;
			default:
				System.out.println("The bonus will be $"+171+".00");
				break;
			
			}
			
		}
	}}}
}
