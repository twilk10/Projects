package hw_2_1302;
//import java.util.*;
/*Original code by Tyler Wilkerson This code prints out the cost and the type of pizza that was given
 * through the constructor of the Delivery Pizza class*/
public class Pizza {
	//private String toppings;
	private double cost;
	private String typeOPizza;
	
	/*This is the constructor
	 * that introduces the type of pizza and the cost and it got its values from the delivery Pizza class
*/
	public Pizza(String x,double y ) {
		this.typeOPizza = x;
		this.cost = y;
	}
	
	
	/*this method uses the values that were put into the constructor and prints out the name and the price
	 * which were given in the constructor it also returns the price so that
	 * I can add it to the delivery fee in the delivery Pizza class*/
	public double pizzaAndCost() {
		
		String h = String.format("%.2f", cost);
		System.out.println(typeOPizza+" pizza cost $"+h);
		return cost;
	}
	/*Scanner sc = new Scanner (System.in);
	public void order() {
		System.out.println("Enter how many Pizzas you want");
		int r = sc.nextInt();
		for(int s =0;s<r;s++) {
		
		System.out.println("Enter the number of toppings you want(you can have up to 3)");
		int h = sc.nextInt();
		while(h>3) {
			System.out.println("Enter a number that is 3 or less");
			h = sc.nextInt();
		}
		if(h!=0) {
		System.out.println("Enter up to three toppings from the toppings below:\n"
				+ "onion\t\tsausage\t\tpineapple"
				+ "\nham\t\tbologna\t\tchicken\npepporoni\t"
				+ "anchovies\tmushrooms");
		}
		String [] y= new String[h];
		for(int i =0; i<h;i++) {
				y[i]=sc.next();
				if(y[i].equals("onion")==false&&y[i].equals("sausage")==false&&y[i].equals("pineapple")==false
						&&y[i].equals("ham")==false&&y[i].equals("bologna")==false&&y[i].equals("chicken")==false
						&&y[i].equals("pepporoni")==false&&y[i].equals("anchovies")==false&&y[i].equals("mushrooms")==false) {
					System.out.println(":( Sorry we do not offer that toppings and if you have chosen olives "
							+ "we kindly request you leave the site\nPlease re-enter a topping ");
					y[i]=sc.next();
				}
					
		}
		if(h==0) {
			cost += 10;
		}else if(h==1) {
			cost+=12;
		}else if(h==2) {
			cost+=15;
		}else if(h==3) {
			cost+=18;
		}
		
		
	}
//		System.out.println(orderCost());
		}
	
	public String orderCost() {
		return "$"+cost+".00";
	}
	public int justorderCost() {
		return cost;
	}*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
