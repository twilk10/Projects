/*Tyler Wilkerson This code displays a frame with a drop box and based off of which 
 * answer choice you choose it will show the capital for that answer choice*/
package hw_4;
//need to import the awt and swing components
import java.awt.*;
import javax.swing.*;


import java.awt.event.*;
/*needs to implement Item listener so that when you choose an option it can display something*/
public class JCapitals extends JFrame implements ItemListener{
static JComboBox f;
static JTextField g;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//sets the height and width of the jframe and it can not be changed
		final int width = 650;
		final int height = 500;
		//this created the object of the class
		JCapitals j = new JCapitals();
		
		JFrame aFrame = new JFrame("Third frame");
		aFrame.setSize(width, height);
		//lets the frame be visible
		aFrame.setVisible(true);
		//lets user exit when they press x 
		aFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel p = new JPanel();
		String[] k =  {"","Austria", "Canada", "England", "France", "Italy", "Mexico", "Spain"};
		//this lets the combo box have the options of everything in the array "k"
		f = new JComboBox(k);
		//adds itemlistener so that when you choose an option something will happen
		f.addItemListener(j);
		aFrame.setLayout(new FlowLayout());
		p.add(f);
		aFrame.add(p);
		JPanel l = new JPanel();
		
		aFrame.add(l);
		System.out.println();
		//This makes the default say nothing is selected
		g = new JTextField("nothing is selected\t     ");
		aFrame.add(g);
		//this shows the frame with everything put in it
		aFrame.show();
		
	}
	public void itemStateChanged(ItemEvent e)
    {
        // if the state combobox is changed
		// {"Vienna", "Toronto", "London", "Paris", "Rome", "Mexico City", "Madrid"}
		
		
		//these if statements will print out the countries capital that is selected when it is selected
        if (e.getSource() == f) {
        	if(f.getSelectedItem().equals(""))
                g.setText("      "+f.getSelectedItem() + "nothing is selected");
 if(f.getSelectedItem().equals("Austria"))
            g.setText("      "+f.getSelectedItem() + "'s Capital is Vienna");
 if(f.getSelectedItem().equals("Canada"))
     g.setText(f.getSelectedItem() + "'s Capital is Toronto");
 if(f.getSelectedItem().equals("England"))
     g.setText(f.getSelectedItem() + "'s Capital is London");
 if(f.getSelectedItem().equals("France"))
     g.setText(f.getSelectedItem() + "'s Capital is Paris");
 if(f.getSelectedItem().equals("Italy"))
     g.setText(f.getSelectedItem() + "'s Capital is Rome");
 if(f.getSelectedItem().equals("Mexico"))
     g.setText(f.getSelectedItem() + "'s Capital is Mexico City");
 if(f.getSelectedItem().equals("Spain"))
     g.setText(f.getSelectedItem() + "'s Capital is Madrid");
        }
    }
}
