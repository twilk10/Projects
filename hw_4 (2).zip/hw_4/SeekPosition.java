/*Tyler Wilkerson this code finds a file and you put in a character to go to and from there the code will

 * print the next 10 characters*/
package hw_4;
import java.io.*;
import java.util.*;
import javax.swing.*;
public class SeekPosition {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		//this creates a random access file which we will later use to find a spot in the file of our choosing
		RandomAccessFile seek;
		File f = new File("input.txt");
		f.createNewFile();
		Scanner sc = new Scanner(System.in);
		  
		   String name;
		   int position;
		   String nxt="";
		   
		   System.out.print("Type in a file name:\t");
		   name=sc.nextLine();
		   System.out.print("Enter position:\t\t");
		   position=sc.nextInt();
		   try{
			   //this uses the file you put in and reads it so that it can get the position of what you just put in
		seek = new RandomAccessFile(new File(name),"r");
		//this goes to the position you put in
		   seek.seek(position);
		   //this is a for loop that moves the position up by one for 10 chars
		   for(int i = 0; i <10; i++) {
				 //This adds the character at the position that the for loop is on
				   nxt+=String.valueOf((char)seek.readByte());
				   
			   }
//		   String s = nxt;
//		   System.out.println(s);
		  //this prints out the string made by all the characters being added together
		   System.out.println(nxt);
	}catch(FileNotFoundException e){
		//This prints out an error if the file you have chosen doesn't exist or could not be found
		   System.out.println("Error You have either chosen a file that doesn't exist or can not be found");
		   
	   }finally {}
	}

}
