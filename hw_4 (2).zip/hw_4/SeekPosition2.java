/*Tyler Wilkerson
 * This code does the same thing as SeekPosition but you can choose 
 * how many characters you want shown instead of it just displaying 10*/
package hw_4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class SeekPosition2 {
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		RandomAccessFile seek;
		File f = new File("input.txt");
		f.createNewFile();
		Scanner sc = new Scanner(System.in);
		  // RandomAccessFile raf = null;
		   String name;
		   int startPosition;
		   //end position will allow the user to put in how many characters they want and then it will
		   //print that many characters
		   int endPosition;
		   String nxt="";
		   
		   System.out.print("Type in a file name:\t");
		   name=sc.nextLine();
		   System.out.print("Enter position:\t\t");
		   startPosition=sc.nextInt();
		   //Here the user puts in the desired number of characters they would like displayed
		   System.out.println("Enter number of characters you would like displayed\t\t");
		   endPosition=sc.nextInt();
		   try{
			   //this uses the file you put in and reads it so that it can get the position of what you just put in

			   seek = new RandomAccessFile(new File(name),"r");
				//this goes to the position you put in

		   seek.seek(startPosition);
		   //this is a for loop that moves the position up by one for however many characters
		   //was put in for endposition

		   for(int i = 0; i <endPosition; i++) {
				 //This adds the character at the position that the for loop is on

				   nxt+=String.valueOf((char)seek.readByte());
				   
			   }
 //this prints out the string made by all the characters being added together

		   System.out.println(nxt);
	}catch(FileNotFoundException e){
		//This prints out an error if the file you have chosen doesn't exist or could not be found

		   System.out.println("Error You have either chosen a file that doesn't exist or can not be found");
		   
	   }finally {}
	}
}
