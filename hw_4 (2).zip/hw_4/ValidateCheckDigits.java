/*Tyler Wilkerson This code reads a file gets the numbers from it checks if it matches a mathematical code
 * and if it does then it will put the number in a new file*/
package hw_4;
import java.nio.file.*;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import static java.nio.file.StandardOpenOption.*;
import java.util.*;
import java.io.FileWriter;
public class ValidateCheckDigits {
	public static void main (String[] args)throws Exception {
		int acctnum;
		int sum;
		int lastDigit;
		int num;
		File s = new File("intro.txt");
	
	   s.createNewFile();/*
	   File l = new File("AcctNumsOut.txt");
	   l.createNewFile();*/
		/*These two paths bring the text files of AcctNumsIn and AcctNumsOut*/
	   Path enter = Paths.get("AcctNumsIn.txt");
       Path exit = Paths.get("AcctNumsOut.txt");
	   
	   //FileWriter myWriter = new FileWriter(new File(exit.toString()));
       //this scanner scans the file instead of a users input
	   Scanner sc = new Scanner(new File(enter.toString()));
	   //this allows you to write in the file that is attatched to the path exit
	   FileWriter good = new FileWriter(new File(exit.toString())); 
       
	   //System.out.println(enter.toString());
	   //This while loop keeps going until there are no next items  
	   while(sc.hasNext()) {
		   //This is the math that is done for the check numbers
		   acctnum=sc.nextInt();
		   num=acctnum;
		   lastDigit=acctnum%10;
	       acctnum=acctnum/10;

	       sum=0;
	      
	      
	       
	       while(acctnum!=0)
	       {
	           // add acc%10 to sum
	           sum+=acctnum%10;

	           // update acc to acc/10
	           acctnum=acctnum/10;
	       }

	       
	       if(sum%10==lastDigit) {
	    	   //if the math is right then it will put the number in the file that we designated
	    	   good.write(num+"\n");
	    	   //System.out.println(num+"\n");
	       }
	       	
	       
	   }

good.close();
	}
	
}
